﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Luckyu.Utility
{
    public class initialPreviewConfig
    {
        public string type { get; set; }

        public int size { get; set; }

        public string downloadUrl { get; set; }

        public string caption { get; set; }

        public string width { get; set; }

        public string url { get; set; }

        public string key { get; set; }
    }
}
