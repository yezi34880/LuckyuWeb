﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Luckyu.Utility
{
    public class ClientDataMapModel
    {
        public string parentId { get; set; }

        public string code { get; set; }

        public string name { get; set; }

        public string value { get; set; }
    }
}
