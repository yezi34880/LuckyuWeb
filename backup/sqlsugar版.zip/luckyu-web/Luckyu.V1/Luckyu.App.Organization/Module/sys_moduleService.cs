﻿using Luckyu.DataAccess;
using Luckyu.Utility;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Luckyu.App.Organization
{
    public class sys_moduleService : RepositoryFactory<sys_moduleEntity>
    {
        public JqgridPageResponse<sys_moduleEntity> Page(JqgridPageRequest jqpage)
        {
            Expression<Func<sys_moduleEntity, bool>> expCondition = r => r.is_delete == 0;
            var dicCondition = new Dictionary<string, Func<string, string, List<IConditionalModel>>>();
            dicCondition.Add("is_enable",
                (field, data) => new List<IConditionalModel> { SearchConditionHelper.GetStringEqualCondition(field, data, "-1") }
                );

            var page = BaseRepository().GetPage(jqpage, expCondition, dicCondition);
            return page;
        }

        public void DeleteForm(sys_moduleEntity entity, UserModel loginInfo)
        {
            entity.Remove(loginInfo);
            BaseRepository().UpdateOnlyColumns(entity, r => new { r.is_delete, r.delete_userid, r.delete_username, r.deletetime });
        }

        public void SaveForm(string keyValue, sys_moduleEntity entity, string strEntity, UserModel loginInfo)
        {
            var trans = BaseRepository().BeginTrans();
            try
            {
                var db = trans.db;
                if (keyValue.IsEmpty())
                {
                    entity.Create(loginInfo);
                    trans.Insert(entity);
                }
                else
                {
                    entity.Modify(keyValue, loginInfo);
                    trans.UpdateAppendColumns(entity, strEntity, r => new { r.edittime, r.edit_userid, r.edit_username });
                }
                trans.Commit();
            }
            catch (Exception ex)
            {
                trans.Rollback();
                throw ex;
            }
        }

    }
}
