﻿using Luckyu.DataAccess;
using Luckyu.Utility;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;

namespace Luckyu.App.Organization
{
    public class sys_dataauthorize_detailService : RepositoryFactory<sys_dataauthorize_detailEntity>
    {
        
    }
}
