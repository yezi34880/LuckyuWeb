﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Luckyu.App.Organization
{
    public enum UserRelationType
    {
        Role = 1,
        Post = 2,
        Group = 3,
        DeptManager = 4,
    }
}
