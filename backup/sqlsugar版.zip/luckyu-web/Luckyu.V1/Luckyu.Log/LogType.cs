﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Luckyu.Log
{
    public enum LogType
    {
        Login = 1,
        Operation = 2,
        Exception = 3,
        Debug = 4,
        Interface = 5,
        Sql = 6,
    }
}
