﻿using Luckyu.App.Organization;
using Luckyu.App.Workflow;
using Luckyu.Utility;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Luckyu.Module.WorkflowModule.Controllers
{
    /// <summary>
    /// 任务委托  /WorkflowModule/Delegate
    /// </summary>
    [Area("WorkflowModule")]
    public class DelegateController : MvcControllerBase
    {
        
    }
}
