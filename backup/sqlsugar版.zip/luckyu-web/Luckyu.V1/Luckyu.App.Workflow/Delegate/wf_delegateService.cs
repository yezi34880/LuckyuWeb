﻿using Luckyu.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Luckyu.App.Workflow
{
    public class wf_delegateService : RepositoryFactory<wf_delegateEntity>
    {

    }
}
