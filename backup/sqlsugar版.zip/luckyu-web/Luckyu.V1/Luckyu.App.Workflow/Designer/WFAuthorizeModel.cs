﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Luckyu.App.Workflow
{
    public class WFAuthorizeModel
    {
        public int objecttype { get; set; }

        public string objectids { get; set; }

        public string objectnames { get; set; }

        public int objectrange { get; set; }
    }
}
