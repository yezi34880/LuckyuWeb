﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Luckyu.App.Workflow
{
    public class WFFormModel
    {
        public string formname { get; set; }

        public string formurl { get; set; }

    }
}
